# -*- coding: utf-8 -*-
import os
import sys
import time
from configparser import ConfigParser

CONNECTOR_DIR = os.path.join(sys.path[1], "connector")
sys.path.append(CONNECTOR_DIR)

import dataiku
import pandas as pd
import requests

from clients.api import RequestToApi


# Get project configuration
config_file = os.path.join(CONNECTOR_DIR, "project.cfg")
project_config = ConfigParser()
project_config.read(config_file)
url = project_config.get("DEFAULT", "url")
project_id = project_config.get("DEFAULT", "project_id")
token = project_config.get("DEFAULT", "token")
agents_dir = project_config.get("DEFAULT", "agents_path")
api = RequestToApi(url, token)


champion_df = pd.DataFrame([[None, None, None, None, None]],
                             columns=["ID", "Score", "Size", "Weights_file", "Config_file"])

while True:
    project = api.get_project(project_id=project_id)
    
    # Get champion
    mutant_id = project["scoreChampionId"] if project["scoreChampionId"] else project["initialMutantId"]
    champion = api.get_mutant(mutant_id=mutant_id)
    champion_df["ID"][0] = champion["agentId"]
    champion_df["Score"][0] = champion["score"]
    champion_df["Size"][0] = champion["size"]
    
    # Get champion config & weights files
    champion_path = os.path.join(CONNECTOR_DIR, agents_dir, project_id, champion["agentId"])
    champion_df["Weights_file"][0] = f"{champion_path}_weights.h5"
    champion_df["Config_file"][0] = f"{champion_path}.config"
        
    if project["status"] != "in_progress":
        break
    else:
        # Get cycle average training time (in seconds)
        response = requests.get(f"{api.url}projects-cycles?projectId={project_id}",
                                headers={"Authorization": f"Bearer {api.auth}"})
        cycles = response.json()["data"]
        if len(cycles) != 0:
            total_train_time = 0
            for cycle in cycles:
                total_train_time += cycle["trainTime"]
            avg_train_time = total_train_time / len(cycles)
            time.sleep(avg_train_time)
        else:
            time.sleep(120)


# Write recipe outputs
champion = dataiku.Dataset("champion")
champion.write_with_schema(champion_df)
