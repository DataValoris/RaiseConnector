# -*- coding: utf-8 -*-
import os
import sys
from configparser import ConfigParser

CONNECTOR_DIR = os.path.join(sys.path[1], "connector")
sys.path.append(CONNECTOR_DIR)

import dataiku
import pandas as pd
from keras import backend as K

import run_population as rp
from clients.api import RequestToApi


# Read recipe inputs
mnist_data = dataiku.Dataset("mnist_normalised").get_dataframe()
labels_OHE = dataiku.Dataset("labels_one_hot_encoding").get_dataframe()

x_train = mnist_data.values[:10000]
y_train = labels_OHE.values[:10000]

x_test = mnist_data.values[10000:11500]
y_test = labels_OHE.values[10000:11500]

# Input image dimensions
img_rows, img_cols = 28, 28

if K.image_data_format() == "channels_first":
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

rp.x_train = x_train
rp.y_train = y_train
rp.x_test = x_test
rp.y_test = y_test


from trainer_model import Trainer

# Model optimization
config_file = os.path.join(CONNECTOR_DIR, "project.cfg")
project_config = ConfigParser()
project_config.read(config_file)
trainer_class = Trainer

cwd = os.getcwd()
os.chdir(CONNECTOR_DIR)

try:
    rp.run_population(project_config=project_config,
                      trainer_class=trainer_class)
except SystemExit:
    pass
finally:
    os.chdir(cwd)


# Get project config
url = project_config.get("DEFAULT", "url")
project_id = project_config.get("DEFAULT", "project_id")
token = project_config.get("DEFAULT", "token")
api = RequestToApi(url, token)
project = api.get_project(project_id=project_id)

project_status_df = pd.DataFrame([[project["name"], project["status"]]],
                                 columns=["project_name", "status"])

# Write recipe outputs
project_status = dataiku.Dataset("project_status")
project_status.write_with_schema(project_status_df)