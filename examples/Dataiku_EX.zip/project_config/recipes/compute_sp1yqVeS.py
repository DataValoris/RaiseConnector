# -*- coding: utf-8 -*-
import json
import os
import random

import dataiku
from keras import backend as K
from keras.layers import Conv2D, Dense, Flatten, Input, MaxPooling2D
from keras.models import Model


# Read recipe inputs
mnist_data = dataiku.Dataset("mnist_normalised").get_dataframe()
labels_OHE = dataiku.Dataset("labels_one_hot_encoding").get_dataframe()

x_train = mnist_data.values[:10000]
y_train = labels_OHE.values[:10000]

x_test = mnist_data.values[10000:11500]
y_test = labels_OHE.values[10000:11500]

# Output dimensions
num_classes = 10

# Input image dimensions
img_rows, img_cols = 28, 28

if K.image_data_format() == "channels_first":
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)


# Create initial model
batch_size = 100
epochs = 5

input_layer = Input(shape=input_shape)
x = Conv2D(filters=random.choice(range(8, 129, 8)),
           kernel_size=random.choice(range(3, 11)),
           activation="relu",
           kernel_initializer="he_normal")(input_layer)
x = MaxPooling2D(pool_size=random.choice(range(2, 5)))(x)
x = Flatten()(x)
output_layer = Dense(num_classes,
                     kernel_initializer="he_normal",
                     activation="softmax")(x)
model = Model(inputs=input_layer, outputs=output_layer)


model.compile(loss="categorical_crossentropy",
              optimizer="Adam",
              metrics=["accuracy"])

model.fit(x_train,
          y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=2,
          validation_data=(x_test, y_test))


# Write recipe inputs
initial_model_path = dataiku.Folder("sp1yqVeS").get_path()

model.save_weights(os.path.join(initial_model_path, "model_weights.h5"), overwrite=True)

with open(os.path.join(initial_model_path, "model.config"), "w") as f:
    json.dump(model.to_json(), f)
