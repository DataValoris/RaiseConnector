# -*- coding: utf-8 -*-
import dataiku


# Read recipe inputs
mnist_data = dataiku.Dataset("mnist").get_dataframe()

# Compute recipe outputs from inputs
mnist_normalised_df = mnist_data / 255

# Write recipe outputs
mnist_normalised = dataiku.Dataset("mnist_normalised")
mnist_normalised.write_with_schema(mnist_normalised_df)
