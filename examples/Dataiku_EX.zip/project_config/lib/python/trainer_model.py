import os

import dataiku
from keras.callbacks import EarlyStopping, ReduceLROnPlateau

import run_population as rp
from examples.itrainer import ITrainer

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

x_train, y_train, x_test, y_test = rp.x_train, rp.y_train, rp.x_test, rp.y_test

class Trainer(ITrainer):
    @staticmethod
    def save_model(model, path_dir="../InitialModel"):
        if not os.path.exists(path_dir):
            os.makedirs(path_dir)
        model.save_weights(os.path.join(
            path_dir, "model_weights.h5"), overwrite=True)
        with open(os.path.join(path_dir, "model.config"), "w") as f:
            json.dump(model.to_json(), f)

    def create_model(self):
        pass

    def train_func(self, model):        
        batch_size = 100
        epochs = 5

        model.compile(loss="categorical_crossentropy",
                      optimizer="Adam",
                      metrics=["accuracy"])
        
        early_stop = EarlyStopping(monitor="val_loss",
                                   min_delta=0,
                                   patience=1,
                                   verbose=0,
                                   mode="auto")
        reduce_lr = ReduceLROnPlateau(monitor="val_loss",
                                      factor=0.2,
                                      patience=1,
                                      min_lr=0.001)
        results = model.fit(x_train,
                            y_train,
                            batch_size=batch_size,
                            epochs=epochs,
                            verbose=2,
                            validation_data=(x_test, y_test),
                            callbacks=[early_stop, reduce_lr])

        train_accuracy = results.history["accuracy"][-1]
        test_accuracy = results.history["val_accuracy"][-1]

        return train_accuracy, test_accuracy

    def evaluate_func(self, model):
        batch_size = 200

        model.compile(loss="categorical_crossentropy",
                      optimizer="Adam",
                      metrics=["accuracy"])
        results = model.evaluate(x_test, y_test, batch_size=batch_size)

        return results[-1]
